document.addEventListener('DOMContentLoaded', function() {
    const registrationForm = document.getElementById('registrationForm');
  
    registrationForm.addEventListener('submit', async function(event) {
      event.preventDefault();
  
      const formData = new FormData(registrationForm);
      const userData = {
        name: formData.get('name'),
        email: formData.get('email'),
        password: formData.get('password')
      };
  
      try {
        const response = await fetch('http://localhost:3000/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(userData)
        });
  
        if (!response.ok) {
          throw new Error('Registration failed');
        }
  
        alert('Registration successful!');
        registrationForm.reset();
      } catch (error) {
        console.error('Error:', error.message);
        alert('Registration failed. Please try again.');
      }
    });
  });
  