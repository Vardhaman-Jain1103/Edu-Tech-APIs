const express = require('express');
const router = express.Router();

const userController = require('../controller/userController');
const userService = require('../services/userService');
const courseService = require('../services/courseService');
const emailService = require('../services/emailService');

router.get('/getUser', userService.getUser);
//router.get('/verifyEmail', userService.verifyEmail);
//router.get('/sendVerificationEmail', emailService.sendVerificationEmail);
router.post('/register',userService.registerUser);
router.put('/update/:id', userService.updateUser);
router.post('/enroll', userService.enrollUser);
router.get('/getCourses', userService.getCourses);
router.post('/loginUser', userService.loginUser);
router.post('/UpdatePass/:id', userService.updatePassword);
router.post('/getFilteredCourses/:filter', userService.getFilteredCourses);
router.post('/createCourse/:id',courseService.createCourse);

router.post('/updateCourse/:id',courseService.updateCourse);
router.get('/getCourse/:id', courseService.getCourses);
router.post('/deleteCourse/:id', courseService.deleteCourse);
//router.get('/send', emailService.send);


module.exports = router;