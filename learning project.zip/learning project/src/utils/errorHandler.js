// errorHandler.js

// Function to handle database errors
const handleDatabaseError = (error, response) => {
  console.error('Database error:', error);
  response.status(500).send('An error occurred while processing your request.');
};

// Function to handle validation errors
const handleValidationError = (error, response) => {
  console.error('Validation error:', error);
  response.status(400).send('Validation error: ' + error.message);
};

// Function to handle unauthorized access errors
const handleUnauthorizedError = (response) => {
  response.status(401).send('Unauthorized access');
};

// Function to handle not found errors
const handleNotFoundError = (response) => {
  response.status(404).send('Resource not found');
};

// Function to handle unexpected errors
const handleUnexpectedError = (error, response) => {
  console.error('Unexpected error:', error);
  response.status(500).send('An unexpected error occurred while processing your request.');
};

// Exporting the error handling functions
module.exports = {
  handleDatabaseError,
  handleValidationError,
  handleUnauthorizedError,
  handleNotFoundError,
  handleUnexpectedError
};
``