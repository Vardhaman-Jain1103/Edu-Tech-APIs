module.exports = {
    secretKey: 'your_secret_key_for_jwt',
    cloudinaryConfig: {
      cloud_name: 'dgyhsgxuz',
      api_key: '482575449183674',
      api_secret: '8zyvzj3Pfjsmk8XZoXBYfpjnveg',
      secure: true
    },
    neonDB: {
      apiKey: '8s2yqorjix0w7wh57vgk6fzaxm8uvj31ihg62hmihi55fzupdat6ih1b37empo98',
      dbName: 'e-learning'
    },
    resendAPIKey: 'your_resend_api_key'
  };
