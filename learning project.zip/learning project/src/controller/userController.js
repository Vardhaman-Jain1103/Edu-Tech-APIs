// Sample code for controllers (e.g., userController.js)
// import sql from './config'
const userService = require('../services/userService');

exports.registerUser = async (req, res, next) => {
  try {
    console.log("R̥equest body", req.body)
    const user = await userService.registerUser(req.body);
    res.json(user);
  } catch (error) {
    next(error);
  }
};

exports.updateUser = async (req, res, next) => {
  try {
    console.log("Request body", req.body);
    const userId = req.params.id;
    const updatedUser = await userService.updateUser(userId, req.body);
    res.json(updatedUser);
  } catch (error) {
    next(error);
  }
};

exports.getUser = async (req, res, next) => {
  try {
    const user = await userService.getUser();
    console.log("User: ",user)
    res.json(user);
  } catch (error) {
    next(error);
  }
};

exports.enrollUser = async (req, res, next) => {
  try {
    const result = await userService.enrollUser(req.body);
    res.json({ message: 'User enrolled successfully', enrollment: result });
  } catch (error) {
    next(error);
  }
};

exports.getCourses = async (req, res, next) => {
  try {
    // Call the service function to retrieve all courses
    const courses = await userService.getCourses();
      // Send the courses as a JSON response
    res.json(courses);
  } catch (error) {
    // Forward any errors to the error handling middleware
    next(error);
  }
};

exports.getFilteredCourses = async (req, res, next) => {
  try {
    const filterBy = req.params.filterBy;
    const filter = req.body.filter
    console.log(filterBy,filter)
    let courses = await userService.getFilteredCourses(filterBy,filter);
    res.json(courses);
  }catch(error){
    next(error);
  }
};


// Other controller methods...