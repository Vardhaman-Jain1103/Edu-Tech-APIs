const nodemailer = require('nodemailer')
exports.send = async function send( to, subject, message) {
  const transporter = nodemailer.createTransport({
    host: 'smtp.resend.com',
    secure: true,
    port: 465,
    auth: {
      user: 'resend',
      pass: 're_iTi2HrGU_5tK9Zo7tebjEc796eUaexiFj',
    },
  });
  const info = await transporter.sendMail({
    from: 'onboarding@resend.dev',
    to: to,
    subject: subject,
    html: message,
  });
  return info;
}
