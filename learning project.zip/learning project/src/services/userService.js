// Sample code for services (e.g., userService.js)
const { Pool } = require("pg");
const bcrypt = require('bcrypt');
const emails = require('./emailService');
const cloudinary = require('cloudinary').v2;
//const { cloudinaryConfig } = require('../config');

const { handleDatabaseError, handleNotFoundError, handleUnexpectedError, handleUnauthorizedError } = require('../utils/errorHandler');
const { request } = require("express");
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false,
  },
});

cloudinary.config({
  cloud_name: 'dgyhsgxuz',
  api_key: '482575449183674',
  api_secret: '8zyvzj3Pfjsmk8XZoXBYfpjnveg',
  secure: true
});

exports.registerUser = (request, response) => {
  const { name, email, password, id } = request.body;

  if (typeof password !== 'string') {
    return response.status(400).send('Password must be a string');
  }

  // Hash the password
  bcrypt.hash(password, 10, (error, hashedPassword) => {
    if (error) {
      handleUnexpectedError(error, response);
      return;
    }

    // File upload using Cloudinary (assuming you're uploading a file named 'photo')
    cloudinary.uploader.upload(request.file.path, (uploadError, result) => {
      if (uploadError) {
        console.error(uploadError);
        return response.status(500).send('Error uploading image to Cloudinary');
      }
      
      const imageUrl = result.secure_url;

      // Insert the user into the database with the image URL
      pool.query(
        `INSERT INTO users (name, email, password, id, image) VALUES ($1, $2, $3, $4, $5) RETURNING *;`,
        [name, email, hashedPassword, id, imageUrl],
        (dbError, results) => {
          if (dbError) {
            handleDatabaseError(dbError, response);
            return;
          }
          const res = emails.send(email, 'Registered Successfully', `${name} Registered Successfully`);
          console.log(res)
          response.status(201).send(email+'\nRegistered Successfully'+`\n${name} Registered Successfully \nUser added with ID: ${results.rows[0].id}`);
        }
      );
    });
  });
};

exports.getUser = async function getUsers(request, response) {
  pool.query(`SELECT * FROM users `, (error, results) => {
    if (error) {
      handleDatabaseError(error, response);
      return;
    }
    response.status(200).json(results.rows);
  });
}

exports.updateUser = (request, response) => {
  const { name, email } = request.body;
  const id = request.params.id;
  
  // Check if a new profile picture file is included in the request
  if (!request.file) {
    // If no new profile picture is provided, proceed with updating name and email only
    pool.query(
      "UPDATE users SET name = $1, email = $2 WHERE id = $3",
      [name, email, id],
      (error, results) => {
        if (error) {
          handleDatabaseError(error, response);
          return;
        }
        if (results.rowCount === 0) {
          handleNotFoundError(response);
          return;
        }
        response.status(200).send(`User modified with ID: ${id}`);
      }
    );
  } else {
    // If a new profile picture is provided, upload it to Cloudinary
    cloudinary.uploader.upload(request.file.path, (uploadError, result) => {
      if (uploadError) {
        console.error(uploadError);
        return response.status(500).send('Error uploading image to Cloudinary');
      }
      
      const newImageUrl = result.secure_url;
      
      // Update the image column in the users table with the new URL
      pool.query(
        "UPDATE users SET name = $1, email = $2, image = $3 WHERE id = $4",
        [name, email, newImageUrl, id],
        (error, results) => {
          if (error) {
            handleDatabaseError(error, response);
            return;
          }
          if (results.rowCount === 0) {
            handleNotFoundError(response);
            return;
          }
          response.status(200).send(`User modified with ID: ${id}`);
        }
      );
    });
  }
};


exports.updatePassword = (request, response) => {
  const { oldPassword, newPassword } = request.body;
  const id = request.params.id;

  // Retrieve the user's current password from the database
  pool.query(
    `SELECT password FROM users WHERE id = $1`,
    [id],
    async (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      // Check if the user exists
      if (results.rows.length === 0) {
        handleNotFoundError(response);
        return;
      }

      // Compare the old password with the stored password
      const hashedPassword = results.rows[0].password;
      try {
        const passwordMatch = await bcrypt.compare(oldPassword, hashedPassword);
        if (passwordMatch) {
          // Hash the new password
          bcrypt.hash(newPassword, 10, (error, hashedNewPassword) => {
            if (error) {
              handleUnexpectedError(error, response);
              return;
            }
            
            // Update the user's password in the database
            pool.query(
              "UPDATE users SET password = $1 WHERE id = $2",
              [hashedNewPassword, id],
              (error, results) => {
                if (error) {
                  handleDatabaseError(error, response);
                  return;
                }
                response.status(200).send(`Password updated for user with ID: ${id}`);
              }
            );
          });
        } else {
          // Old password provided is incorrect
          handleUnauthorizedError(response);
          //response.status(401).send('Incorrect old password');
          return
        }
      } catch (error) {
        // Handle unexpected error
        //console.error('Error comparing passwords:', error);
        handleUnexpectedError(error, response);
        return
      }
    }
  );
};

exports.enrollUser = (request, response) => {
  const { userId, courseId } = request.body;
  let userEmail = '', courseName = '';

  // Check if the user is already enrolled
  pool.query(
    `SELECT * FROM course_enroll WHERE userid = $1 AND courseid = $2`,
    [userId, courseId],
    (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      // If the user is already enrolled, send a response indicating that
      if (results.rows.length > 0) {
        response.status(400).send(`User has already enrolled in this course`);
        return;
      }

      // If the user is not already enrolled, proceed with enrollment
      pool.query(
        `INSERT INTO course_enroll (userid, courseid) VALUES ($1, $2) RETURNING *`,
        [userId, courseId],
        (error, results) => {
          if (error) {
            handleDatabaseError(error, response);
            return;
          }

          // If the enrollment is successful, retrieve the user's email and course name
          pool.query(
            `SELECT email FROM users WHERE id = $1`,
            [userId],
            (error, emailResults) => {
              if (error) {
                handleDatabaseError(error, response);
                return;
              }
              if (emailResults) {
                userEmail = emailResults.rows[0].email;
                pool.query(
                  `SELECT name FROM courses WHERE id = $1`,
                  [courseId],
                  (error, courseResults) => {
                    if (error) {
                      handleDatabaseError(error, response);
                      return;
                    }
                    if (courseResults) {
                      courseName = courseResults.rows[0].name;
                    }
                    // Send enrollment confirmation email
                    const res = emails.send(userEmail, 'Enrolled Successfully', `${courseName} Enrolled Successfully`);
                    console.log(res);
                    response.status(201).send(`User enrolled successfully. User email: ${userEmail}, MessageId: ${res}`);
                  }
                );
              }
            }
          );
        }
      );
    }
  );
};

exports.getCourses = (request, response) => {
  const { page = 1, limit = 10 } = request.query;
  const offset = (page - 1) * limit;

  // Query to fetch current page data
  const currentPageQuery = {
    text: `SELECT name FROM courses ORDER BY id LIMIT $1 OFFSET $2`,
    values: [limit, offset]
  };

  // Query to fetch data for the next page
  const nextPageQuery = {
    text: `SELECT name FROM courses ORDER BY id LIMIT $1 OFFSET $2`,
    values: [limit, offset + limit]
  };

  pool.query(currentPageQuery, (error, currentPageResults) => {
    if (error) {
      handleDatabaseError(error, response);
      return;
    }

    // Execute the query for the next page
    pool.query(nextPageQuery, (error, nextPageResults) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      response.status(200).json({
        currentPageData: currentPageResults.rows,
        nextPageData: nextPageResults.rows
      });
    });
  });
};

exports.getFilteredCourses = (request, response) => {
  const filter = request.body.filter;
  const filterBy = request.params.filter;
  try {
    // const result = await sql`select * from courses where popularity = $1` ;
    pool.query(
      `SELECT name FROM courses where ${filterBy} = $1`,
      [filter],
      (error, results) => {
        if (error) {
          handleDatabaseError(error, response);
          return;
        }
        response.status(200).json(results.rows);
      }
    );
  }
  catch (error) {
    console.error(error);
    handleUnexpectedError(error, response);
    // throw new Error('Failed to enroll user in course');
  }
}

// Function to retrieve enrolled course names for a user
async function getEnrolledCourseNames(userId) {
  return new Promise((resolve, reject) => {
    pool.query(
      `SELECT courses.name FROM courses
       INNER JOIN course_enroll ON courses.id = course_enroll.courseid
       WHERE course_enroll.userid = $1`,
      [userId],
      (error, results) => {
        if (error) {
          reject(error);
        } else if (!results || !results.rows) {
          // Check if results are undefined or if results.rows is undefined
          resolve([]); // Return an empty array if no results found
        } else {
          const enrolledCourseNames = results.rows.map(course => course.name);
          resolve(enrolledCourseNames);
        }
      }
    );
  });
}

exports.loginUser = (request, response) => {
  const { email, password } = request.body;

  // Retrieve the user from the database using the provided email
  pool.query(
    `SELECT * FROM users WHERE email = $1`,
    [email],
    async (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      // Check if the user exists
      if (results.rows.length === 0) {
        handleNotFoundError(response);
        return;
      }

      // Compare the hashed password with the provided password
      const user = results.rows[0];
      const hashedPassword = user.password;
      try {
        const result = await bcrypt.compare(password, hashedPassword);
        if (result) {
          // Passwords match, user is authenticated
          // Retrieve and send enrolled course names as response
          const enrolledCourseNames = await getEnrolledCourseNames(user.id); // Remove quotes around user.id
          response.status(200).json({
            message: 'Login successful',
            user: {
              id: user.id,
              email: user.email,
              enrolledCourseNames: enrolledCourseNames // Include enrolled course names in response
            }
          });
        } else {
          // Passwords don't match
          handleUnauthorizedError(response);
          return
          //response.status(401).send('Invalid credentials');
        }
      } catch (error) {
        // Handle unexpected error
        //console.error('Error comparing passwords:', error);
        handleUnexpectedError(error, response);
        return
      }
    }
  );
};
