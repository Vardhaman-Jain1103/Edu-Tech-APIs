// Sample code for services (e.g., userService.js)
const { Pool } = require("pg");
require('dotenv').config();
const { handleDatabaseError, handleNotFoundError, handleUnauthorizedError, handleUnexpectedError } = require('../utils/errorHandler');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false,
  },
});

exports.createCourse = (request, response) => {
  const { id, name, category, level, popularity } = request.body;
  const userid = request.params.id;

  // Fetch the usertype from the user table based on the provided id
  pool.query(
    `SELECT userType FROM users WHERE id = $1`,
    [userid],
    (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      // Check if user with provided id exists
      if (results.rows.length === 0) {
        handleNotFoundError(response);
        return;
      }

      const userType = results.rows[0].usertype;

      if (userType !== 'admin') {
        handleUnauthorizedError(response);
        return;
      }

      // Proceed with inserting the course if the user is authorized
      pool.query(
        `INSERT INTO courses (id, name, category, level, popularity) VALUES ($1, $2, $3, $4, $5) RETURNING *;`,
        [id, name, category, level, popularity],
        (error, results) => {
          if (error) {
            handleDatabaseError(error, response);
            return;
          }
          response.status(201).send(`Course added with ID: ${results.rows[0].id}`);
        }
      );
    }
  );
};

exports.updateCourse = (request, response) => {
  const { name, category, level, popularity, courseid } = request.body;
  const userid = request.params.id;

  // Fetch the usertype from the user table based on the provided id
  pool.query(
    `SELECT usertype FROM users WHERE id = $1`,
    [userid],
    (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      if (results.rows.length === 0) {
        handleNotFoundError(response);
        return;
      }

      const userType = results.rows[0].usertype;

      if (userType !== 'admin') {
        handleUnauthorizedError(response);
        return;
      }

      // Proceed with updating the course if the user is authorized

      pool.query(
        `UPDATE courses SET name = $1, category = $2, level = $3, popularity = $4 WHERE id = $5 RETURNING *;`,
        [name, category, level, popularity, courseid],
        (error, results) => {
          if (error) {
            handleDatabaseError(error, response);
            return;
          }
          if (results.rows.length === 0) {
            handleNotFoundError(response);
            return;
          }
          response.status(200).send(`Course updated with ID: ${results.rows[0].id}`);
        }
      );
    }
  );
};

exports.getCourses = (request, response) => {
  const userid = request.params.id;

  // Fetch the usertype from the user table based on the provided id
  pool.query(
    `SELECT usertype FROM users WHERE id = $1`,
    [userid],
    (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      if (results.rows.length === 0) {
        handleNotFoundError(response);
        return;
      }

      const userType = results.rows[0].usertype;

      if (userType !== 'admin') {
        handleUnauthorizedError(response);
        return;
      }

      // Proceed with updating the course if the user is authorized

      pool.query(`SELECT * FROM courses`, (error, results) => {
        if (error) {
          handleDatabaseError(error, response);
          return;
        }
        response.status(200).json(results.rows);
      });
    }
  );
};

exports.deleteCourse = (request, response) => {
  const { courseid } = request.body;
  const userid = request.params.id;

  // Fetch the usertype from the user table based on the provided id
  pool.query(
    `SELECT usertype FROM users WHERE id = $1`,
    [userid],
    (error, results) => {
      if (error) {
        handleDatabaseError(error, response);
        return;
      }

      if (results.rows.length === 0) {
        handleNotFoundError(response);
        return;
      }

      const userType = results.rows[0].usertype;

      if (userType !== 'admin') {
        handleUnauthorizedError(response);
        return;
      }

      // Proceed with updating the course if the user is authorized

      pool.query(
        `DELETE FROM courses WHERE id = $1 RETURNING *;`,
        [courseid],
        (error, results) => {
          if (error) {
            handleDatabaseError(error, response);
            return;
          }
          if (results.rows.length === 0) {
            handleNotFoundError(response);
            return;
          }
          response.status(200).send(`Course updated with ID: ${results.rows[0].id}`);
        }
      );
    }
  );
};
